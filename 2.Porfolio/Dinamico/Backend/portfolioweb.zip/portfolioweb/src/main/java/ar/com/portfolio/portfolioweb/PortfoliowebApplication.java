package ar.com.portfolio.portfolioweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfoliowebApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortfoliowebApplication.class, args);
	}

}
