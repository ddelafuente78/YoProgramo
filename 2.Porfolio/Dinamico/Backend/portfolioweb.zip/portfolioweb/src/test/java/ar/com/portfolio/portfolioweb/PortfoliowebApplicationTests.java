package ar.com.portfolio.portfolioweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortfoliowebApplicationTests {

	@Test
	void contextLoads() {
	}

}
